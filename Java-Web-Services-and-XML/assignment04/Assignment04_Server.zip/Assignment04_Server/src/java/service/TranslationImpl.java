package service;

import java.io.FileNotFoundException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.xml.xpath.XPathExpressionException;

@WebService(endpointInterface = "service.Translation")
public class TranslationImpl implements Translation {

    @Override
    public String translate(String originalWord, String fromLang, String toLang) {

        XMLSource source = new XMLSource();
        String translatedWord = null;

        try {
            translatedWord = source.getTranslate(originalWord, fromLang, toLang);
        } catch (XPathExpressionException | FileNotFoundException ex) {
            Logger.getLogger(TranslationImpl.class.getName()).log(Level.SEVERE, null, ex);
        }

        return translatedWord;

    }

}
