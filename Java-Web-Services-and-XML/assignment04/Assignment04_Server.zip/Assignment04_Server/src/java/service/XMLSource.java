package service;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.xml.sax.InputSource;

public class XMLSource {

    public String getTranslate(String originalWord, String fromLang, String toLang) throws XPathExpressionException, FileNotFoundException {

        XPathFactory factory = XPathFactory.newInstance();
        XPath path = factory.newXPath();

        // File xmlDocument = new File("dictionary.xml");
        File xmlDocument = new File("C:\\Assignment04_Server\\build\\web\\dictionary.xml");
        InputSource source = new InputSource(new FileInputStream(xmlDocument));

        XPathExpression expression = path.compile("//word[" + fromLang + " = '" + originalWord + "']/" + toLang + "");

        String translatedWord = (String) expression.evaluate(source, XPathConstants.STRING);

        if (!translatedWord.equals("")) {
            return "Prevod: " + translatedWord;
        } else {
            return "Ne postoji trazena rec u recniku!";
        }

    }

}
