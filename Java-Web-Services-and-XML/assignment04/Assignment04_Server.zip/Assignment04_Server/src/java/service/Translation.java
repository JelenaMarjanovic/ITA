package service;

import javax.jws.WebMethod;
import javax.jws.WebService;

@WebService
public interface Translation {

    @WebMethod
    String translate(String originalWord, String fromLang, String toLang);

}
