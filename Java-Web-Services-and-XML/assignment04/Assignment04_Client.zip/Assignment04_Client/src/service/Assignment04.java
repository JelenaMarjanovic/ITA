package service;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class Assignment04 {

    public static void main(String[] args) throws MalformedURLException {

        URL url = new URL("http://localhost:8080//Assignment04_Server/TranslationImplService?wsdl");
        QName qName = new QName("http://service/", "TranslationImplService");
        Service service = Service.create(url, qName);
        QName port = new QName("http://service/", "TranslationImplPort");

        Translation translation = service.getPort(port, Translation.class);

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("Unesite jezik sa kog zelite da prevedete rec"
                    + "\n(u ponudi su \"english\" i \"serbian\"):");
            String fromLang = sc.next();
            String toLang = null;

            if (fromLang.equalsIgnoreCase("english") || fromLang.equalsIgnoreCase("serbian")) {

                if (fromLang.equalsIgnoreCase("english")) {
                    System.out.println("Unesite englesku rec za koju zelite prevod:");
                    toLang = "serbian";
                } else {
                    System.out.println("Unesite srpsku rec za koju zelite prevod:");
                    toLang = "english";
                }

                String originalWord = sc.next();

                System.out.println(translation.translate(originalWord, fromLang, toLang));

                System.out.println("Da li zelite prevod za neku drugu rec? (DA / NE)");
                String answer = sc.next();

                if (answer.equalsIgnoreCase("NE")) {
                    break;
                }

            } else {
                System.out.println("Navedeni jezik nije u ponudi!");
            }

        }

        sc.close();

    }

}
